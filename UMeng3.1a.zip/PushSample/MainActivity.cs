﻿using Android.App;
using Android.Widget;
using Android.OS;
using Com.Umeng.Message;
using Android.Content;
using Com.Umeng.Message.Entity;
using System;

namespace PushSample
{
    [Activity(Label = "PushSample", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);
            SetContentView(Resource.Layout.Main);

            PushAgent pushAgent = PushAgent.GetInstance(this);
            pushAgent.SetDebugMode(false);
            pushAgent.MessageHandler = new MyMsgHandler();
            pushAgent.Register(new MyRegister(this));
            pushAgent.OnAppStart();
            var id = pushAgent.RegistrationId;
        }
    }

    class MyRegister : Java.Lang.Object, IUmengRegisterCallback
    {
        Activity a;
        public MyRegister(Activity a)
        {
            this.a = a;
        }
        public void OnFailure(string p0, string p1)
        {
            a.RunOnUiThread(() => Toast.MakeText(a, $"注册失败 {p0} {p1}", ToastLength.Long).Show());
        }

        public void OnSuccess(string p0)
        {
            a.RunOnUiThread(() => Toast.MakeText(a, $"注册成功 token={p0}", ToastLength.Long).Show());
        }
    }

    class MyMsgHandler : UmengMessageHandler
    {
        public override Notification GetNotification(Context p0, UMessage p1)
        {
            return base.GetNotification(p0, p1);
        }

        public override void DealWithCustomMessage(Context p0, UMessage p1)
        {
            base.DealWithCustomMessage(p0, p1);
        }
    }
}


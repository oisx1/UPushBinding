﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Java.Lang;

namespace Com.Umeng.Message
{
    public partial class UmengDownloadResourceService : global::Android.App.Service
    {
        public partial class DownloadResourceTask : global::Android.OS.AsyncTask
        {
            protected override Java.Lang.Object DoInBackground(params Java.Lang.Object[] @params)
            {
                return "";
            }
        }
    }
}